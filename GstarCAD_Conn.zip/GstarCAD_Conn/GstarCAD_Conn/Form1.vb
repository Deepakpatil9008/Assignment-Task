﻿Imports System.IO
Imports System.Threading
Imports GrxCAD

Imports Gssoft.Gscad
Imports Gssoft.Gscad.Runtime
Imports GcadVbaLib
Public Class Form1

    Dim GCadApp As GcadApplication
    Dim GCadDoc As Object
    Dim strFileName As String
    Dim strcommandlayerABC As String = ""
    Dim strcommandlayerPQR As String = ""
    Dim strCMDSaveDwg As String
    Dim strCMDFiledia As String
    Dim i As Integer
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click

        strFileName = TextBox1.Text

        If Process.GetProcessesByName("gcad").Length > 0 Then
            GCadApp = CType(GetObject(, "gcad.application"), GcadApplication)
            GCadDoc = GCadApp.Documents.Open(strFileName, False)
            GCadDoc = GCadApp.ActiveDocument
            'Else createObject
        Else
            GCadApp = New GcadApplication
            GCadApp.Visible = True
            GCadApp.WindowState = GcWindowState.acMax
            GCadDoc = GCadApp.Documents.Open(strFileName, False)
            GCadDoc = GCadApp.ActiveDocument
        End If

        Thread.Sleep(1000)

        'Dim strcommand = "(C:tba " & """" & strInputfile & """" & ")"
        If RB_ABC_Show.Checked = True Then
            strcommandlayerABC = "(vla-put-layeron (vla-item (vla-get-layers (vla-get-activedocument (vlax-get-acad-object ))) " & """" & "ABC" & """)" & " :vlax-true)"
            GCadDoc.SendCommand(strcommandlayerABC & " ")
        ElseIf RB_ABC_Hide.Checked = True Then
            strcommandlayerABC = "(vla-put-layeron (vla-item (vla-get-layers (vla-get-activedocument (vlax-get-acad-object ))) " & """" & "ABC" & """)" & " :vlax-false)"
            GCadDoc.SendCommand(strcommandlayerABC & " ")
        End If

        If RB_PQR_Show.Checked = True Then
            strcommandlayerABC = "(vla-put-layeron (vla-item (vla-get-layers (vla-get-activedocument (vlax-get-acad-object ))) " & """" & "PQR" & """)" & " :vlax-true)"
            GCadDoc.SendCommand(strcommandlayerABC & " ")
        ElseIf RB_PQR_Hide.Checked = True Then
            strcommandlayerABC = "(vla-put-layeron (vla-item (vla-get-layers (vla-get-activedocument (vlax-get-acad-object ))) " & """" & "PQR" & """)" & " :vlax-false)"
            GCadDoc.SendCommand(strcommandlayerABC & " ")
        End If

        i = i + 1

        ' ("._QSAVE\n", false, false, true)
        strFileName = Path.GetDirectoryName(strFileName) & "\Test_" & CStr(i) & ".dwg"
        strFileName = strFileName.Replace("\", "\\")

        strCMDFiledia = "Filedia 0"
        GCadDoc.SendCommand(strCMDFiledia & " ")

        GCadDoc.SaveAs(strFileName, True)

        strCMDFiledia = "Filedia 1"
        GCadDoc.SendCommand(strCMDFiledia & " ")

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        Dim fd As OpenFileDialog = New OpenFileDialog()

        fd.Title = "Open File Dialog"
        fd.InitialDirectory = "D:\"
        'fd.Filter = "All files (*.*)|*.*|All files (*.*)|*.*"
        fd.Filter = "Drawing Files|*.dwg"
        fd.FilterIndex = 2
        fd.RestoreDirectory = True

        If fd.ShowDialog() = DialogResult.OK Then
            strFileName = fd.FileName
            TextBox1.Text = fd.FileName
        End If


    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        End
    End Sub
End Class
