﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.RB_ABC_Hide = New System.Windows.Forms.RadioButton()
        Me.RB_ABC_Show = New System.Windows.Forms.RadioButton()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.RB_PQR_Hide = New System.Windows.Forms.RadioButton()
        Me.RB_PQR_Show = New System.Windows.Forms.RadioButton()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(14, 28)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(217, 21)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Select the Model / Drawing :- "
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(224, 24)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(244, 28)
        Me.TextBox1.TabIndex = 1
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(474, 22)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(108, 32)
        Me.Button1.TabIndex = 2
        Me.Button1.Text = "Browse"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(18, 262)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(108, 32)
        Me.Button2.TabIndex = 5
        Me.Button2.Text = "Generate"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(247, 262)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(108, 32)
        Me.Button3.TabIndex = 6
        Me.Button3.Text = "Cancel"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.RB_ABC_Hide)
        Me.GroupBox1.Controls.Add(Me.RB_ABC_Show)
        Me.GroupBox1.Location = New System.Drawing.Point(18, 82)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(337, 78)
        Me.GroupBox1.TabIndex = 9
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Layer Type 1"
        '
        'RB_ABC_Hide
        '
        Me.RB_ABC_Hide.AutoSize = True
        Me.RB_ABC_Hide.Location = New System.Drawing.Point(194, 33)
        Me.RB_ABC_Hide.Name = "RB_ABC_Hide"
        Me.RB_ABC_Hide.Size = New System.Drawing.Size(136, 25)
        Me.RB_ABC_Hide.TabIndex = 9
        Me.RB_ABC_Hide.TabStop = True
        Me.RB_ABC_Hide.Text = "Layer ABC Hide"
        Me.RB_ABC_Hide.UseVisualStyleBackColor = True
        '
        'RB_ABC_Show
        '
        Me.RB_ABC_Show.AutoSize = True
        Me.RB_ABC_Show.Location = New System.Drawing.Point(17, 35)
        Me.RB_ABC_Show.Name = "RB_ABC_Show"
        Me.RB_ABC_Show.Size = New System.Drawing.Size(142, 25)
        Me.RB_ABC_Show.TabIndex = 8
        Me.RB_ABC_Show.TabStop = True
        Me.RB_ABC_Show.Text = "Layer ABC Show"
        Me.RB_ABC_Show.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.RB_PQR_Hide)
        Me.GroupBox2.Controls.Add(Me.RB_PQR_Show)
        Me.GroupBox2.Location = New System.Drawing.Point(18, 166)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(337, 78)
        Me.GroupBox2.TabIndex = 10
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Layer Type 2"
        '
        'RB_PQR_Hide
        '
        Me.RB_PQR_Hide.AutoSize = True
        Me.RB_PQR_Hide.Location = New System.Drawing.Point(188, 26)
        Me.RB_PQR_Hide.Name = "RB_PQR_Hide"
        Me.RB_PQR_Hide.Size = New System.Drawing.Size(137, 25)
        Me.RB_PQR_Hide.TabIndex = 10
        Me.RB_PQR_Hide.TabStop = True
        Me.RB_PQR_Hide.Text = "Layer PQR Hide"
        Me.RB_PQR_Hide.UseVisualStyleBackColor = True
        '
        'RB_PQR_Show
        '
        Me.RB_PQR_Show.AutoSize = True
        Me.RB_PQR_Show.Location = New System.Drawing.Point(11, 28)
        Me.RB_PQR_Show.Name = "RB_PQR_Show"
        Me.RB_PQR_Show.Size = New System.Drawing.Size(143, 25)
        Me.RB_PQR_Show.TabIndex = 9
        Me.RB_PQR_Show.TabStop = True
        Me.RB_PQR_Show.Text = "Layer PQR Show"
        Me.RB_PQR_Show.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 21.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(593, 303)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.Label1)
        Me.Font = New System.Drawing.Font("Calibri", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.MaximizeBox = False
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Open Model / Drawing in GstarCAD"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents Button1 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents RB_ABC_Hide As RadioButton
    Friend WithEvents RB_ABC_Show As RadioButton
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents RB_PQR_Hide As RadioButton
    Friend WithEvents RB_PQR_Show As RadioButton
End Class
